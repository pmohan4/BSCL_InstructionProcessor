/**
 * 
 */
package com.bscl.processor;

/**
 * @author Prakash
 *
 */
public class InstructionMessage {

	private final int instructionType;
	private final int productCode;
	private final int quantity;
	private final int uom;
	private final int timeStamp;
	
	/**
	 * @param instructionType
	 * @param productCode
	 * @param quantity
	 * @param uom
	 * @param timeStamp
	 */
	public InstructionMessage(int instructionType, int productCode,
			int quantity, int uom, int timeStamp) {
		super();
		this.instructionType = instructionType;
		this.productCode = productCode;
		this.quantity = quantity;
		this.uom = uom;
		this.timeStamp = timeStamp;
	}

	/**
	 * @return the instructionType
	 */
	public int getInstructionType() {
		return instructionType;
	}

	/**
	 * @return the productCode
	 */
	public int getProductCode() {
		return productCode;
	}

	/**
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * @return the uom
	 */
	public int getUom() {
		return uom;
	}

	/**
	 * @return the timeStamp
	 */
	public int getTimeStamp() {
		return timeStamp;
	}

}

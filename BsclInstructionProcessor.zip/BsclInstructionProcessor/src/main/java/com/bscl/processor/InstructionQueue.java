/**
 * 
 */
package com.bscl.processor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * @author Prakash
 *
 */
public class InstructionQueue {

	private List<InstructionMessage> queue = new ArrayList<InstructionMessage>();
	
	/**
	 * Method to add instruction message to the queue
	 * @param message {@link InstructionMessage}
	 * @return true if added successfully else false
	 */
	public boolean addMessage(InstructionMessage message) {
		if(message == null || !isValidMessage(message)){
			throw new InvalidMessageException("Invalid Message");
		}
		queue.add(message);
		this.sort();
		return true;
	}
	
	/**
	 * Method to return number of message in the queue
	 * @return int number of message
	 */
	public int getCount() {
		return queue.size();
	}
	
	/**
	 * Method to delete given {@link InstructionMessage}
	 * @param message
	 * @return true if deleted successfully else false
	 */
	public boolean deleteMessage(InstructionMessage message) {
		return queue.remove(message);
	}
	
	/**
	 * Method to retrive first {@link InstructionMessage}
	 * @return {@link InstructionMessage}
	 */
	public InstructionMessage getMessage() {
		return queue.remove(0);
	}
	
	/**
	 * Method to determine is message queue is empty
	 * @return true if queue is empty else false
	 */
	public boolean isEmpty() {
		return queue.isEmpty();
	}
	
	private void sort() {
		Collections.sort(queue, new Comparator<InstructionMessage>() {

			public int compare(InstructionMessage o1, InstructionMessage o2) {
				int iType1 = o1.getInstructionType();
				int iType2 = o2.getInstructionType();
				
				if(inBetween(iType1, iType2, 0, 11, 0, 11)
						|| inBetween(iType1, iType2, 10, 91, 10, 91)
						|| inBetween(iType1, iType2, 90, 100, 90, 100)) {
					return 0;
				} else {
					return iType1 - iType2;
				}
			}

			private boolean inBetween(int iType1, int iType2, int start1, int end1, int start2, int end2) {
				return (iType1 > start1 && iType1 < end1) && (iType2 > start2 && iType2 < end2);
			}
			
		});
	}
	
	private boolean isValidMessage(InstructionMessage message) {
		return ((message.getInstructionType() > 0 
				&& message.getInstructionType() < 100)
				&& message.getProductCode() > 0
				&& message.getQuantity() > 0
				&& (message.getUom() >= 0 && message.getUom() < 256)
				&& message.getTimeStamp() > 0);
	}


}

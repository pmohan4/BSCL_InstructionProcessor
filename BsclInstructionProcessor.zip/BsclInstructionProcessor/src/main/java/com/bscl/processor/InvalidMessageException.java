package com.bscl.processor;

/**
 * @author Prakash
 *
 */
public class InvalidMessageException extends RuntimeException {

	private static final long serialVersionUID = 4736108893098201568L;

	public InvalidMessageException(String message){
		super(message);
	}
}

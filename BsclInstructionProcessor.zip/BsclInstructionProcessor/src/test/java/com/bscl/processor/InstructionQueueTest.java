/**
 * 
 */
package com.bscl.processor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

/**
 * @author Prakash
 *
 */
public class InstructionQueueTest {

	private InstructionQueue instructionQueue;
	
	@Rule
	public ExpectedException expectedEx = ExpectedException.none();
	
	@Before
	public void setUp() throws Exception {
		instructionQueue = new InstructionQueue();
	}

	@After
	public void tearDown() throws Exception {
		instructionQueue = null;
	}

	@Test
	public void testAddMessage() {
		//fail("Not yet implemented");
		assertTrue(instructionQueue.addMessage(createInstructionMessage(10, 1620, 15, 200, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(23, 123, 356, 55, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(99, 1023, 367, 87, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(23, 1345, 475, 0, 1489242842)));
		
	}
	
	@Test
	public void testMessageSortedBasedOnPriority() {
		//fail("Not yet implemented");
		assertTrue(instructionQueue.addMessage(createInstructionMessage(27, 1345, 475, 0, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(10, 1620, 15, 200, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(23, 123, 356, 55, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(99, 1023, 367, 87, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(24, 1345, 475, 0, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(92, 1023, 367, 87, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(99, 1023, 367, 87, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(90, 1345, 475, 0, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(3, 1345, 475, 0, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(2, 1345, 475, 0, 1489242842)));
		
		assertEquals(10, instructionQueue.getMessage().getInstructionType());
		assertEquals(3, instructionQueue.getMessage().getInstructionType());
		assertEquals(2, instructionQueue.getMessage().getInstructionType());
		assertEquals(27, instructionQueue.getMessage().getInstructionType());
		assertEquals(23, instructionQueue.getMessage().getInstructionType());
		assertEquals(24, instructionQueue.getMessage().getInstructionType());
		assertEquals(90, instructionQueue.getMessage().getInstructionType());
		
		assertTrue(instructionQueue.addMessage(createInstructionMessage(16, 1345, 475, 0, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(7, 1345, 475, 0, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(98, 1345, 475, 0, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(16, 1345, 475, 0, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(7, 1345, 475, 0, 1489242842)));
		
		assertEquals(7, instructionQueue.getMessage().getInstructionType());
		assertEquals(7, instructionQueue.getMessage().getInstructionType());
		assertEquals(16, instructionQueue.getMessage().getInstructionType());
		assertEquals(16, instructionQueue.getMessage().getInstructionType());
		
		assertEquals(99, instructionQueue.getMessage().getInstructionType());
		assertEquals(92, instructionQueue.getMessage().getInstructionType());
		assertEquals(99, instructionQueue.getMessage().getInstructionType());
		assertEquals(98, instructionQueue.getMessage().getInstructionType());
		
	}

	@Test
	public void testGetCount() {
		//fail("Not yet implemented");
		assertEquals(0, instructionQueue.getCount());
		assertTrue(instructionQueue.addMessage(createInstructionMessage(10, 1620, 15, 200, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(23, 123, 356, 55, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(99, 1023, 367, 87, 1489242842)));
		assertEquals(3, instructionQueue.getCount());
	}

	@Test
	public void testDeleteMessage() {
		//fail("Not yet implemented");
		
		InstructionMessage im1 = createInstructionMessage(10, 1620, 15, 200, 1489242842);
		InstructionMessage im2 = createInstructionMessage(23, 123, 356, 55, 1489242842);
		InstructionMessage im3 = createInstructionMessage(99, 1023, 367, 87, 1489242842);
		
		assertEquals(0, instructionQueue.getCount());
		
		instructionQueue.addMessage(im1);
		instructionQueue.addMessage(im2);
		instructionQueue.addMessage(im3);
		assertEquals(3, instructionQueue.getCount());
		
		instructionQueue.deleteMessage(im2);
		assertEquals(2, instructionQueue.getCount());
	}

	@Test
	public void testGetMessage() {
		//fail("Not yet implemented");
		assertTrue(instructionQueue.addMessage(createInstructionMessage(10, 1620, 15, 200, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(23, 123, 356, 55, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(99, 1023, 367, 87, 1489242842)));
		assertEquals(3, instructionQueue.getCount());
		
		InstructionMessage im = instructionQueue.getMessage();
		assertEquals(10, im.getInstructionType());
		assertEquals(1620, im.getProductCode());
		assertEquals(15, im.getQuantity());
		assertEquals(200, im.getUom());
		assertEquals(1489242842, im.getTimeStamp());
		
		assertEquals(2, instructionQueue.getCount());
		
	}

	@Test
	public void testIsEmpty() {
		//fail("Not yet implemented");
		assertTrue(instructionQueue.isEmpty());
		assertTrue(instructionQueue.addMessage(createInstructionMessage(10, 1620, 15, 200, 1489242842)));
		assertTrue(instructionQueue.addMessage(createInstructionMessage(23, 123, 356, 55, 1489242842)));
		assertFalse(instructionQueue.isEmpty());
	}
	
	@Test
	public void testAddMessageWithInvalidInstructionType() {
		expectedEx.expect(InvalidMessageException.class);
		expectedEx.expectMessage("Invalid Message");
		instructionQueue.addMessage(createInstructionMessage(343, 1620, 15, 200, 1489242842));
	}
	
	@Test
	public void testAddMessageWithInvalidNegativeInstructionType() {
		expectedEx.expect(InvalidMessageException.class);
		expectedEx.expectMessage("Invalid Message");
		instructionQueue.addMessage(createInstructionMessage(-23, 1620, 15, 200, 1489242842));
	}
	
	@Test
	public void testAddMessageWithInvalidZeroInstructionType() {
		expectedEx.expect(InvalidMessageException.class);
		expectedEx.expectMessage("Invalid Message");
		instructionQueue.addMessage(createInstructionMessage(0, 1620, 15, 200, 1489242842));
	}
	
	
	@Test
	public void testAddMessageWithInvalidProductCode() {
		expectedEx.expect(InvalidMessageException.class);
		expectedEx.expectMessage("Invalid Message");
		instructionQueue.addMessage(createInstructionMessage(47, -788, 15, 200, 1489242842));
	}

	@Test
	public void testAddMessageWithInvalidZeroProductCode() {
		expectedEx.expect(InvalidMessageException.class);
		expectedEx.expectMessage("Invalid Message");
		instructionQueue.addMessage(createInstructionMessage(47, 0, 15, 200, 1489242842));
	}
	
	@Test
	public void testAddMessageWithInvalidQuatity() {
		expectedEx.expect(InvalidMessageException.class);
		expectedEx.expectMessage("Invalid Message");
		instructionQueue.addMessage(createInstructionMessage(47, 134, -15, 200, 1489242842));
	}
	
	@Test
	public void testAddMessageWithInvalidZeroQuatity() {
		expectedEx.expect(InvalidMessageException.class);
		expectedEx.expectMessage("Invalid Message");
		instructionQueue.addMessage(createInstructionMessage(47, 134, 0, 200, 1489242842));
	}
	
	@Test
	public void testAddMessageWithInvalidIUOM() {
		expectedEx.expect(InvalidMessageException.class);
		expectedEx.expectMessage("Invalid Message");
		instructionQueue.addMessage(createInstructionMessage(343, 1620, 15, 256, 1489242842));
	}
	
	@Test
	public void testAddMessageWithInvalidNegativeUOM() {
		expectedEx.expect(InvalidMessageException.class);
		expectedEx.expectMessage("Invalid Message");
		instructionQueue.addMessage(createInstructionMessage(-23, 1620, 15, -200, 489242842));
	}
	
	@Test
	public void testAddMessageWithInvalidITimestampe() {
		expectedEx.expect(InvalidMessageException.class);
		expectedEx.expectMessage("Invalid Message");
		instructionQueue.addMessage(createInstructionMessage(343, 1620, 15, 255, -1489242842));
	}
	
	@Test
	public void testAddMessageNull() {
		expectedEx.expect(InvalidMessageException.class);
		expectedEx.expectMessage("Invalid Message");
		instructionQueue.addMessage(null);
	}
	
	private static InstructionMessage createInstructionMessage(int instructionType, int productCode,
			int quantity, int uom, int timeStamp) {
		return new InstructionMessage(instructionType, productCode, quantity, uom, timeStamp);
	}
}
